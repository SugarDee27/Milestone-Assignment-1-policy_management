from Policyholder import Policyholder
from Product import Product
from Payment import Payment

def demo_run():
    try:
        # Create Products
        product1 = Product(101, "Life Insurance", 500)
        product2 = Product(102, "Car Insurance", 300)

        # Create Policyholders
        holder1 = Policyholder(1, "Disere Leghemo")
        holder2 = Policyholder(2, "Richard Obioha")

        # Register Policyholders
        holder1.register()
        holder2.register()

        # Assign products
        holder1.add_product(product1)
        holder2.add_product(product2)

        # Create Payments
        payment1 = Payment(201, holder1, product1.price)
        payment2 = Payment(202, holder2, product2.price)

        # Process Alice’s payment
        payment1.process_payment()
        holder1.add_payment(payment1)

        # Richard hasn’t paid yet
        payment2.send_reminder()
        payment2.apply_penalty(50)
        payment2.process_payment()
        holder2.add_payment(payment2)

        # Display account details
        holder1.show_details()
        holder2.show_details()

    except Exception as e:
        print(f"Error occurred: {e}")

if __name__ == "__main__":
    demo_run()
