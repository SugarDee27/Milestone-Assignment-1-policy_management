class Payment:
    def __init__(self, payment_id, policyholder, amount):
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.amount = amount
        self.status = "Pending"

    def process_payment(self):
        if self.policyholder.status != "Active":
            raise Exception(f"Cannot process payment. Policyholder {self.policyholder.name} is {self.policyholder.status}.")
        if self.amount <= 0:
            raise ValueError("Payment amount must be greater than zero.")
        self.status = "Paid"
        print(f"Payment of ${self.amount} processed for {self.policyholder.name}.")

    def send_reminder(self):
        print(f"Reminder: {self.policyholder.name}, your payment of ${self.amount} is pending.")

    def apply_penalty(self, penalty_amount):
        if self.status == "Paid":
            raise Exception(f"Penalty cannot be applied. Payment {self.payment_id} already completed.")
        self.amount += penalty_amount
        print(f"Penalty of ${penalty_amount} applied. New amount due: ${self.amount}.")
