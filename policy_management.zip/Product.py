class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.status = "Active"

    def update(self, name=None, price=None):
        if name:
            self.name = name
        if price:
            self.price = price
        print(f"Product {self.product_id} updated successfully.")

    def suspend(self):
        self.status = "Suspended"
        print(f"Product {self.name} has been suspended.")

    def activate(self):
        self.status = "Active"
        print(f"Product {self.name} is active again.")
