from Product import Product
from Payment import Payment

class Policyholder:
    def __init__(self, holder_id, name):
        self.holder_id = holder_id
        self.name = name
        self.status = "Inactive"
        self.products = []
        self.payments = []

    def register(self):
        self.status = "Active"
        print(f"Policyholder {self.name} registered successfully.")

    def suspend(self):
        self.status = "Suspended"
        print(f"Policyholder {self.name} has been suspended.")

    def reactivate(self):
        if self.status == "Suspended":
            self.status = "Active"
            print(f"Policyholder {self.name} has been reactivated.")

    def add_product(self, product: Product):
        if self.status != "Active":
            raise Exception(f"Cannot assign product to {self.name}. Policyholder is {self.status}.")
        self.products.append(product)
        print(f"Product {product.name} assigned to {self.name}.")

    def add_payment(self, payment: Payment):
        if self.status != "Active":
            raise Exception(f"Cannot add payment to {self.name}. Policyholder is {self.status}.")
        self.payments.append(payment)

    def show_details(self):
        print("\n--- Policyholder Details ---")
        print(f"ID: {self.holder_id}")
        print(f"Name: {self.name}")
        print(f"Status: {self.status}")
        print("Products:")
        for p in self.products:
            print(f"   - {p.name} (${p.price}, {p.status})")
        print("Payments:")
        for pay in self.payments:
            print(f"   - Amount: ${pay.amount}, Status: {pay.status}")
        print("----------------------------")
